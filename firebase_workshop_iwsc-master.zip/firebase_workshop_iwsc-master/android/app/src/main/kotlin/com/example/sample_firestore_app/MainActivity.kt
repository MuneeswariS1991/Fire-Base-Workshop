package com.example.sample_firestore_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
